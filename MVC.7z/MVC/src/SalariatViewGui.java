import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class SalariatViewGui implements ViewSalariat{

	ActionListener actionListener;
	
	JFrame frame = new JFrame("Salariat");
	JLabel numeSalariat = new JLabel("Nume salariat: ");
	JLabel vechimeSalariat = new JLabel("Vechime salariat: ");
	JLabel salariuSalariat = new JLabel("Salariu salariat: ");
	JButton button = new JButton();
	
	public SalariatViewGui() {

		JPanel panel = new JPanel();
		panel.setLayout(new FlowLayout());

		button = new JButton();
		button.setText("Incrementeaza salariu");
		//button.setActionCommand();

		//button.addActionListener(this.actionListener);
			  
		panel.add(numeSalariat);
		panel.add(vechimeSalariat);
		panel.add(salariuSalariat);
		panel.add(button);

		frame.add(panel);
		frame.setSize(400, 400);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public void setActionListener(ActionListener actionListener) {
		this.actionListener = actionListener;
		this.button.addActionListener(this.actionListener);
	}
	
	
	
	public void printDetaliiSalariat(String nume, Integer vechimea, Double salariu) 
	 { 
		numeSalariat.setText("Nume salariat: "+nume);
		vechimeSalariat.setText("Vechime salariat: "+vechimea);
		salariuSalariat.setText("Salariu salariat: "+salariu);
	 } 
}
