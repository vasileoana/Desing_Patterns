import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SalariatController {
	
	private Salariat model;
	//private ViewSalariat view;
	private SalariatViewGui view;
	
	//Daca am dori sa avem mai multe viewuri, cum sa selectez?
//	public SalariatController(Salariat modelSalariat, ViewSalariat viewSalariat) {
//		this.model = modelSalariat;
//		this.view = viewSalariat;
//	}
	
	public SalariatController(Salariat modelSalariat, SalariatViewGui viewSalariat) {
		this.model = modelSalariat;
		this.view = viewSalariat;
		
		this.view.setActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				model.setVechime(model.getVechime()+1);
				view.printDetaliiSalariat(model.getNume(), model.getVechime(), model.getSalariu());
			}
		});
	}
	
	public void setNumeSalariat(String nume) {
		model.setNume(nume);
	}
	
	public String getNumeSalariat() {
		return model.getNume();
	}
	
	public void setVechimeSalariat(Integer vechime) {
		model.setVechime(vechime);
	}
	
	public Integer getVechimeSalariat() {
		return model.getVechime();
	}
	
	public void setSalariuSalariat(Double salariu) {
		model.setSalariu(salariu);
	}
	
	public Double getSalariuSalariat() {
		return model.getSalariu();
	}
	
	public void updateView() 
    {                 
        view.printDetaliiSalariat(model.getNume(), model.getVechime(), model.getSalariu()); 
    } 

}
