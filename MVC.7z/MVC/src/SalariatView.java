
public class SalariatView implements ViewSalariat{

	 public void printDetaliiSalariat(String numeSalariat, Integer vechimea, Double salariu) 
	 { 
	        System.out.println("Salariat: "); 
	        System.out.println("Nume: " + numeSalariat); 
	        System.out.println("Vechimea: " + vechimea);
	        System.out.println("Salariu: " + salariu);
	 } 
}
