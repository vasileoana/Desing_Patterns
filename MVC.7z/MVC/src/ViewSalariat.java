
public interface ViewSalariat {

	public void printDetaliiSalariat(String numeSalariat, Integer vechimea, Double salariu);
}
