import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {

	public static void main(String[] args) {

		Salariat s1 = new Salariat();
		s1.setNume("Ion");
		s1.setVechime(14);
		s1.setSalariu(1450D);
		
		SalariatView salariatView = new SalariatView();
		SalariatViewGui gui = new SalariatViewGui();
		
		SalariatController controller = new SalariatController(s1, gui);
		
		controller.updateView();
//		
//		int ani = 30;
//		while (ani != 0) {
//			controller.getSalariuSalariat();
//			controller.updateView();
//			s1.setVechime(s1.getVechime()+1);
//			ani--;
//		}
		
		
		
		
	}

}
