

public class Salariat {

	private String nume;
	private Integer vechime;
	private Double salariu;
	
	public String getNume() {
		return nume;
	}
	public void setNume(String nume) {
		this.nume = nume;
	}
	public Integer getVechime() {
		return vechime;
	}
	public void setVechime(Integer vechime) {
		this.vechime = vechime;
	}
	
	public Double getSalariu() {
		
		if(this.getVechime() < 10) {
			this.setSalariu(this.salariu*1.08);
        } else if( this.getVechime() >= 10 && this.getVechime() < 15){
        	this.setSalariu(this.salariu*1.1);
        } else if( this.getVechime() >= 15 && this.getVechime() < 20){
        	this.setSalariu(this.salariu*1.15);
        } else if( this.getVechime() >= 20 ) {
        	this.setSalariu(this.salariu*1.2);
        }
		return salariu;
	}
	
	public void setSalariu(Double salariu) {
		this.salariu = salariu;
	}
	
	
}
