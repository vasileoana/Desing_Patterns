package objpool.observable;

import objpool.ObjectPool;
import objpool.Resursa;

public class Abonat {

    private String nume;
    private Resursa r;

    public Abonat(String name){
        this.nume = name;
    }

    public Resursa getResource(ObjectPool objectPool) {
        this.r = objectPool.get();
        if(r == null) {
            objectPool.aboneazaAbonat(this);
        }
        return r;
    }

    public void elibereazaReursa(Resursa r, ObjectPool objectPool){
        objectPool.release(r);
    }

    public void setResursa(Resursa r) {
        this.r = r;
    }

    public void dezaboneaza(ObjectPool objectPool){
        objectPool.dezaboneazaAbonat(this);
    }

    @Override
    public String toString() {
        return "Abonat{" +
                "nume='" + nume + '\'' +
                ", r=" + r +
                '}';
    }
}
