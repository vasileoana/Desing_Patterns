package objpool;

import objpool.observable.Abonat;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

public class ObjectPool {

    private ConcurrentLinkedQueue<Resursa> list;
    private static ObjectPool instance = null;
    private static List<Abonat> abonati = new ArrayList<>();

    public static ObjectPool getInstance() {
        if (instance == null) {
            instance = new ObjectPool();

        }
        return instance;
    }

    private ObjectPool() {
        list = new ConcurrentLinkedQueue<>();
        list.add(new Resursa(1, "desc"));
        list.add(new Resursa(2, "desc2"));
    }


    public Resursa get() {
        System.out.println("Mai sunt: " + instance.list.size() + " resurse!");
        Resursa r = instance.list.poll();
        return r;
    }

    public void release(Resursa r) {
        if (r != null) {
            if (instance.list.size() == 0) {
                instance.list.offer(r);
                this.notifica(r);
            }
        }
    }

    public void aboneazaAbonat(Abonat a) {
        abonati.add(a);
    }

    public void dezaboneazaAbonat(Abonat a) {
        abonati.remove(a);
    }

    public void notifica(Resursa r) {
        for (Abonat a : abonati) {
            a.setResursa(r);
            a.dezaboneaza(this);
        }
        System.out.println("S-a eliberat resursa:" + r.getDescriere());
    }

}
