import objpool.ObjectPool;
import objpool.Resursa;
import objpool.observable.Abonat;

public class Main {

   public static void main(String [] args){

       ObjectPool objectPool = ObjectPool.getInstance();
       Resursa r = objectPool.get();
       if(r!= null){
           r.utilizeaza();
       }
       objectPool.release(r);

       Resursa r2 = objectPool.get();
       if(r2!= null){
           r2.utilizeaza();
       }



       Abonat a = new Abonat("haha");
       Resursa res = a.getResource(objectPool);
       if(res != null){
           res.utilizeaza();
       }
       a.elibereazaReursa(res, objectPool);

       System.out.println(a);


       objectPool.release(r2);

       System.out.println(a);


   }
}
