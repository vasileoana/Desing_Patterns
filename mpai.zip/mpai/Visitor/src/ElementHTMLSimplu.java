public class ElementHTMLSimplu extends  ElementHTML {


    public ElementHTMLSimplu(String etichetaStart, String etichetaEnd) {
        super(etichetaStart, etichetaEnd);
    }

    @Override
    public void accept(Visitor v, String val) {
        v.visit(this, val);
    }

    @Override
    public String afiseaza() {
        return super.toString();
    }


}
