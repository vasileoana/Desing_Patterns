public interface Visitor {


   public void visit(ElementHTML elementHTML, String value);

}
