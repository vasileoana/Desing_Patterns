import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        System.out.println("VISITOR");


        Visitor cssIdVisitor = new CSSIdVisitor();
        ElementHTML body = new ElementHTMLSimplu("<a", "</a>");
        body.accept(cssIdVisitor, "container");
        System.out.println(body.afiseaza());


        ElementHTML bodyEl = new ElementHTMLCompus("<html","</html>",   new ArrayList<ElementHTML>() {{ add(body); }});
        bodyEl.accept(cssIdVisitor, "container");
        System.out.println(bodyEl.afiseaza());

    }

}
