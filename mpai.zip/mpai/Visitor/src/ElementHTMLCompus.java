import java.util.List;

public class ElementHTMLCompus extends ElementHTML {

List<ElementHTML> elementHTMLS;


    public ElementHTMLCompus(String etichetaStart, String etichetaEnd, List<ElementHTML> elementHTMLS) {
        super(etichetaStart, etichetaEnd);
        this.elementHTMLS = elementHTMLS;
    }

    public List<ElementHTML> getElementHTMLS() {
        return elementHTMLS;
    }


    @Override
    void accept(Visitor v, String value) {
        for(ElementHTML elementHTML : elementHTMLS)
        v.visit(elementHTML, value);
    }


    @Override
    public String afiseaza() {
    return null;
    }


}
