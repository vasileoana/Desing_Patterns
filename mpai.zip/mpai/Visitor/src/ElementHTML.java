public abstract class ElementHTML {

    private String etichetaStart;
    private String etichetaEnd;

    public ElementHTML(String etichetaStart, String etichetaEnd) {
        this.etichetaStart = etichetaStart;
        this.etichetaEnd = etichetaEnd;
    }

    public String getEtichetaStart() {
        return etichetaStart;
    }

    public String getEtichetaEnd() {
        return etichetaEnd;
    }

    abstract void  accept(Visitor v, String val);


    abstract String afiseaza();

    @Override
    public String toString() {
        return "ElementHTML:" +
               etichetaStart + '\'';
                
    }


    public void setEtichetaStart(String etichetaStart) {
        this.etichetaStart = etichetaStart;
    }

    public void setEtichetaEnd(String etichetaEnd) {
        this.etichetaEnd = etichetaEnd;
    }
}
