package producerconsumer;

import java.util.LinkedList;
import java.util.Queue;


public class Broker {
    public boolean isAvaialbe() {
        return isAvaialbe;
    }

    public void setAvaialbe(boolean avaialbe) {
        isAvaialbe = avaialbe;
    }

    private Queue<Integer> items;
    private boolean isAvaialbe;

    public Broker() {
        this.items = new LinkedList<>();
        this.isAvaialbe = true;
    }

    public synchronized Integer getItem()  {
        try {
            if(this.items.size() < 1) {
                this.setAvaialbe(false);
                return null;
            } else {
                this.setAvaialbe(true);
                return this.items.poll();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void addItem(Integer item)  {
        try {
            this.items.add(item);
            this.isAvaialbe = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
