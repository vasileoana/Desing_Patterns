package producerconsumer;

import java.util.Random;

public class Producer implements Runnable {

    private Broker broker;
    private int NrProducts = 10;


    public Producer(Broker broker) {
        this.broker = broker;
    }

    @Override
    public void run() {
        while(NrProducts >= 0){
            Random r = new Random();
            Integer value = new Integer(r.nextInt(100));
            broker.addItem(value);
            NrProducts --;
            System.out.println("Proucatorul a produs: " + value );
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
