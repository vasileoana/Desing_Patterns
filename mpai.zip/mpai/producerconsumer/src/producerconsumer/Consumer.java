package producerconsumer;

public class Consumer extends Thread {

    private Broker broker;

    public Consumer(Broker broker) {
        this.broker = broker;
    }

    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (broker.isAvaialbe()) {
                Integer i = broker.getItem();
                if(i != null){
                System.out.println("Consumatorul a consumat: " + i.toString());
            } else {
                    System.out.println("Nu mai sunt consumabile");
                }
            } else {
                System.out.println("Nu mai sunt disponibile");
                break;
            }
        }
    }
}
