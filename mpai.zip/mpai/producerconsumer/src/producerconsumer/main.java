package producerconsumer;


public class main {

    public static void main(String[] args) {

        //Creating shared object
        Broker broker = new Broker();

        //Creating Producer and Consumer Thread
        Thread prodThread = new Thread(new Producer(broker));
        Consumer c = new Consumer(broker);
        Consumer c2 = new Consumer(broker);

        //Starting producer and Consumer thread
        prodThread.start();

        c.start();

        c2.start();

//        try {
////            Thread.sleep(5000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
    }

}

