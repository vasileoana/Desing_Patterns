package proxy;

public class GeneratorRaportReal implements  Raport {
    @Override
    public void scrieRaport(Angajat a) {
        System.out.println("Raportel catre: " + a.getName());

    }
}
