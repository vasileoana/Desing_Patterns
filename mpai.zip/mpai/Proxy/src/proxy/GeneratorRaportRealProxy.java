package proxy;

public class GeneratorRaportRealProxy implements Raport {

    GeneratorRaportReal generatorRaportReal;

    public GeneratorRaportRealProxy(GeneratorRaportReal generatorRaportReal) {
        this.generatorRaportReal = generatorRaportReal;
    }

    @Override
    public void scrieRaport(Angajat a) {
        if(a.isEligibile) {
            generatorRaportReal.scrieRaport(a);
        }
        else {
            System.out.println("Acces forbidden for: " + a.getName());
        }
    }
}
