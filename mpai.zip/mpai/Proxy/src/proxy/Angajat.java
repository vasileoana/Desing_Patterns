package proxy;

public class Angajat {

    boolean isEligibile;
    String name;

    public Angajat(boolean isEligibile, String name) {
        this.isEligibile = isEligibile;
        this.name = name;
    }

    public boolean isEligibile() {
        return isEligibile;
    }

    public void setEligibile(boolean eligibile) {
        isEligibile = eligibile;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
