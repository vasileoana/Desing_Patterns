package proxy;

public interface Raport {

    void scrieRaport(Angajat a);

}
