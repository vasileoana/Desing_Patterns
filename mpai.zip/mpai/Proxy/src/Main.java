import proxy.Angajat;
import proxy.GeneratorRaportReal;
import proxy.GeneratorRaportRealProxy;

public class Main {


    public static void main(String[] args){

        GeneratorRaportRealProxy generatorRaportRealProxy = new GeneratorRaportRealProxy(new GeneratorRaportReal());

        Angajat a = new Angajat(true, "Oana");
        generatorRaportRealProxy.scrieRaport(a);
         a = new Angajat(false, "Ioana");
        generatorRaportRealProxy.scrieRaport(a);

    }
}
