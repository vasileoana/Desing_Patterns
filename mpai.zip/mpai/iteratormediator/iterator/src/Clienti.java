import java.util.Iterator;
import java.util.List;

public class Clienti {

    class Iterator {
        public Client first(){
            poz = 0;
            return clients[poz];
        }

        public Client last(){
            poz= clients.length -1;
            return clients[poz];
        }


        public Client getValue(){
            return  clients[poz];
        }

        public void prev(){
         poz--;
        }

        public void next(){
            poz++;
        }


        public boolean isDone(){
            if(poz == clients.length || poz < 0){
                return true;
            }
            return false;
        }

    }

    Client[] clients;
    int poz = 0;


    public Iterator getIterator(){
        return new Iterator();
    }

    public Clienti(Client[] clients) {
        this.clients = clients;
    }
}
