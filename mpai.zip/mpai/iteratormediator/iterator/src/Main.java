import java.util.Iterator;

public class Main {

    public static void main(String args[]) {
        Client[] clients = new Client[] {
            new Client("AnA", "sa"), new Client("DanA", "swde")
        };

        Clienti clienti = new Clienti(clients);


        Clienti.Iterator it =  clienti.getIterator();
        it.first();
        while(!it.isDone()){
            System.out.println(it.getValue().toString());
            it.next();
        }


        Clienti.Iterator it2 =  clienti.getIterator();
        it2.last();
        while(!it2.isDone()){
            System.out.println(it2.getValue().toString());
            it2.prev();
        }
    }

}
