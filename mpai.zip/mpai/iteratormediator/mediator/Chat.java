import java.util.List;

public class Chat extends Mediator {

    List<User> userList;

    public Chat( List<User> userList) {
        this.userList = userList;
    }

    @Override
    public void sendMessage(String message) {
        for (User user: userList) {
            user.receiveMessage(message);
        }
}
}
