public abstract class Mediator {

    public abstract void sendMessage(String message);

}
