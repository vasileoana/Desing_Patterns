import java.util.ArrayList;

public class Main {

    public static void main(String args[]) {

      Mediator mediator = new Chat(new ArrayList<>());
        User user1 = new Mobile(mediator);

    }
}
