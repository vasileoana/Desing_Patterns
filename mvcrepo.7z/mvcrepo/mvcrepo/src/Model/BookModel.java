package Model;

public class BookModel {
    private String titlu;
    private String autor;
    private String pret;
    private String stoc;

    public BookModel(){

    }

    public BookModel(String titlu, String autor, String pret, String stoc) {
        this.titlu = titlu;
        this.autor = autor;
        this.pret = pret;
        this.stoc = stoc;
    }

    public String getTitlu() {
        return titlu;
    }

    public void setTitlu(String titlu) {
        this.titlu = titlu;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getPret() {
        return pret;
    }

    public void setPret(String pret) {
        this.pret = pret;
    }

    public String getStoc() {
        return stoc;
    }

    public void setStoc(String stoc) {
        this.stoc = stoc;
    }

    @Override
    public String toString() {
        return "BookModel{" +
            "titlu='" + titlu + '\'' +
            ", autor='" + autor + '\'' +
            ", pret='" + pret + '\'' +
            ", stoc='" + stoc + '\'' +
            '}';
    }
}
