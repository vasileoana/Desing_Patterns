import Repository.BookRepository;

public class Main {

    public static void main(String[] args) {
       BookRepository.getInstance().readAll();
        BookRepository.getInstance().save();
    }

}
