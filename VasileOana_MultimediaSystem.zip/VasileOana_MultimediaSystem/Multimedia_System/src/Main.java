import facade.MultimediaSystemFacade;

public class Main {
    public static void main(String[] args) throws Exception {

       //fisier text valid
        MultimediaSystemFacade.openText("Proiect.docx");
        //fisier text inexistent
        MultimediaSystemFacade.openText("fisier inexistent.doc");
        //fisier existent cu extensie gresita
        MultimediaSystemFacade.openText("joke.jpg");

        //imagine valida
        MultimediaSystemFacade.openImage("joke.jpg");

        // exemple de apel pentru celelalte sisteme
//        MultimediaSystemFacade.openGraphic("");
//        MultimediaSystemFacade.openAnimation("");
//        MultimediaSystemFacade.playAudio("");
//        MultimediaSystemFacade.playVideo("");

    }
}
