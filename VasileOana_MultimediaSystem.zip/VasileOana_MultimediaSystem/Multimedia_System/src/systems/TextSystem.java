package systems;

import util.FileUtil;
import util.MediaType;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;

public class TextSystem implements IMedia {

    public static TextSystem instance = null;

    private TextSystem() {
    }

    public static TextSystem getInstance() {
        if (instance == null) {
            instance = new TextSystem();
        }
        return instance;
    }

    @Override
    public void open(File mediaFile) {
        if (checkValidity(mediaFile)) {
            Desktop dt = Desktop.getDesktop();
            try {
                dt.open(mediaFile);
            } catch (IOException e) {
                System.out.println("Exception, text file is not valid!");
            }
            System.out.println("--- Text " + mediaFile.getName() + " opened! ---");
        } else {
            System.out.println("Exception, text file is not valid!");
        }

    }

    @Override
    public void describe(File mediaFile) {
        System.out.println("-> The media file: " + mediaFile.getName()
                + " with path: " + mediaFile.getAbsolutePath());
        if (checkValidity(mediaFile)) {
            System.out.println("it is a valid text ");
            System.out.println("is last modified on : " + new Date(mediaFile.lastModified()).toString());
        } else {
            System.out.println("it is not a valid text ");
        }
        System.out.println("has: " + mediaFile.length() + "Bytes\n");

    }

    @Override
    public boolean checkValidity(File mediaFile) {
        return (Arrays.asList(MediaType.TEXT.getExtensions()).contains(FileUtil.getExtension(mediaFile.getName()))
                && mediaFile.length() > 0);
    }


}
