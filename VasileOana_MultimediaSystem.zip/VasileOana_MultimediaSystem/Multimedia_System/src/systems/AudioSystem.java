package systems;

import util.FileUtil;
import util.MediaType;

import java.io.File;
import java.util.Arrays;
import java.util.Date;

public class AudioSystem implements IMedia {

    private static AudioSystem instance = null;

    private AudioSystem() {}

    public static AudioSystem getInstance() {
        if (instance == null) {
            instance = new AudioSystem();
        }
        return instance;
    }

    @Override
    public void open(File mediaFile) {
        if (checkValidity(mediaFile)) {
            System.out.println("--- The audio " + mediaFile.getName() + " started! ---");
        }
        else {
            System.out.println("Exception, audio file is not valid!");
        }
    }

    @Override
    public void describe(File mediaFile) {
        System.out.println("-> The media file: " + mediaFile.getName()
                + " with path: " + mediaFile.getAbsolutePath());
        if (checkValidity(mediaFile)) {
            System.out.println("it is a valid audio file ");
            System.out.println("is last modified on : " + new Date(mediaFile.lastModified()).toString());
        } else {
            System.out.println("it is not a valid audio file ");
        }
        System.out.println("has: " + mediaFile.length() + "Bytes\n");
    }

    @Override
    public boolean checkValidity(File mediaFile) {
        return (Arrays.asList(MediaType.AUDIO.getExtensions()).contains(FileUtil.getExtension(mediaFile.getName()))
                && mediaFile.length() > 0);
    }

}