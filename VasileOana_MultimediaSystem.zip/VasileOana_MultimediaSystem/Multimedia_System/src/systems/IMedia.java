package systems;

import java.io.File;

public interface IMedia {

    /** Open the media file
     *  @param  mediaFile  a file generated based on the given full path
     *  @see File **/
    void open(File mediaFile);

    /** Describe the media file: file name, full path, last modified date, size
     * @param mediaFile  a file generated based on the given full path
     * @see File **/
    void describe(File mediaFile);

    /** Checks if the media file exists and has the expected extension
     * @param mediaFile a file generated based on the given full path
     * @return if the media file is valid or not **/
    boolean checkValidity(File mediaFile);


}
