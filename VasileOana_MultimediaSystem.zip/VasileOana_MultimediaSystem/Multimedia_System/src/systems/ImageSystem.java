package systems;

import adaptee.Image;
import adaptee.OldImageSystem;
import util.FileUtil;
import util.MediaType;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;

public class ImageSystem implements IMedia {

    private static ImageSystem instance = null;

    private OldImageSystem oldImageSystem;

    private ImageSystem() {
        this.oldImageSystem = new OldImageSystem();
    }

    public static ImageSystem getInstance() {
        if (instance == null) {
            instance = new ImageSystem();
        }
        return instance;
    }

    @Override
    public void open(File mediaFile){
        if (checkValidity(mediaFile)) {
            Desktop dt = Desktop.getDesktop();
            try {
                dt.open(mediaFile);
            } catch (IOException e) {
                System.out.println("Exception, image file is not valid!");
            }
           this.oldImageSystem.openImage(new Image(mediaFile.getName()));
        } else {
            System.out.println("Exception, image file is not valid!");
        }
    }

    @Override
    public void describe(File mediaFile) {
        System.out.println("-> The media file: " + mediaFile.getName()
                + " with path: " + mediaFile.getAbsolutePath());
        if (checkValidity(mediaFile)) {
            System.out.println("it is a valid image ");
            System.out.println("is last modified on : " + new Date(mediaFile.lastModified()).toString());
        } else {
            System.out.println("it is not a valid image ");
        }
        System.out.println("has: " + mediaFile.length() + "Bytes\n");
    }

    @Override
    public boolean checkValidity(File mediaFile) {
        return (Arrays.asList(MediaType.IMAGE.getExtensions()).contains(FileUtil.getExtension(mediaFile.getName()))
                && mediaFile.length() > 0);
    }


}


