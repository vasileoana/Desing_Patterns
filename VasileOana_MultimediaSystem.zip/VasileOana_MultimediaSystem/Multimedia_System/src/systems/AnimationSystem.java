package systems;


import util.FileUtil;
import util.MediaType;

import java.io.File;
import java.util.Arrays;
import java.util.Date;

public class AnimationSystem implements IMedia {

    private static AnimationSystem instance = null;

    private AnimationSystem() {}

    public static AnimationSystem getInstance() {
        if (instance == null) {
            instance = new AnimationSystem();
        }
        return instance;
    }

    @Override
    public void open(File mediaFile) {
        if (checkValidity(mediaFile)) {
            System.out.println("--- Animation " + mediaFile.getName() + " opened! ---");
        } else {
            System.out.println("Exception, animation file is not valid!");
        }
    }

    @Override
    public void describe(File mediaFile) {
        System.out.println("-> The media file: " + mediaFile.getName()
                + " with path: " + mediaFile.getAbsolutePath());
        if (checkValidity(mediaFile)) {
            System.out.println("it is a valid animation ");
            System.out.println("is last modified on : " + new Date(mediaFile.lastModified()).toString());
        } else {
            System.out.println("it is not a valid animation ");
        }
        System.out.println("has: " + mediaFile.length() + "Bytes\n");

    }

    /** Checks if the media file exists and has the expected extension
     * @param mediaFile a file generated based on the given full path
     * @return if the media file is valid or not **/
    @Override
    public boolean checkValidity(File mediaFile) {
        return (Arrays.asList(MediaType.ANIMATION.getExtensions()).contains(FileUtil.getExtension(mediaFile.getName()))
                && mediaFile.length() > 0);
    }


}
