package multiton;

import systems.*;
import util.MediaType;

import java.util.HashMap;
import java.util.Map;

public class MediaSystemRegistry {
    private static Map<MediaType, IMedia> mediaSystemMap = new HashMap<>();

    private MediaSystemRegistry() {}

    public static IMedia getInstance(MediaType mediaType) {
        if (!mediaSystemMap.containsKey(mediaType)) {
            switch (mediaType) {
                case VIDEO:
                    mediaSystemMap.put(MediaType.VIDEO, VideoSystem.getInstance());
                    break;
                case IMAGE:
                    mediaSystemMap.put(MediaType.IMAGE, ImageSystem.getInstance());
                    break;
                case AUDIO:
                    mediaSystemMap.put(MediaType.AUDIO, AudioSystem.getInstance());
                    break;
                case TEXT:
                    mediaSystemMap.put(MediaType.TEXT, TextSystem.getInstance());
                    break;
                case ANIMATION:
                    mediaSystemMap.put(MediaType.ANIMATION, AnimationSystem.getInstance());
                    break;
                case GRAPHIC:
                    mediaSystemMap.put(MediaType.GRAPHIC, GraphicSystem.getInstance());
                    break;
            }
        }
        return mediaSystemMap.get(mediaType);

    }
}
