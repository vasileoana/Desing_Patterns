package adaptee;

public class OldImageSystem {

    public void openImage(Image image) {
        System.out.println("Image: " + image.getName() + " opened!");
    }

}
