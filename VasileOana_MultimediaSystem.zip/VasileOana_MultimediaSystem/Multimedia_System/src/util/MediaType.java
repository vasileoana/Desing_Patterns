package util;

public enum MediaType {
    ANIMATION("gif", "apng"),
    AUDIO("mp3"),
    GRAPHIC("svg"),
    IMAGE("png", "jpg", "bpg", "jpeg"),
    TEXT("txt", "text", "pdf", "doc", "docx"),
    VIDEO("mp3", "flv", "avi");

    private final String[] extensions;

    public String[] getExtensions() {
        return extensions;
    }

    MediaType(String... extensions) {
        this.extensions = extensions;
    }


}
