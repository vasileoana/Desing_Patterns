package util;

public class FileUtil {
    private FileUtil(){}

    /** Gets the extension from a given path
     * @param mediaFilePath the absolute path of a file
     * @return the extension of the file */
    public static String getExtension(String mediaFilePath) {
        String extension = "";
        int i = mediaFilePath.lastIndexOf('.');
        if (i > 0) {
            extension = mediaFilePath.substring(i + 1);
        }
        return extension;
    }

}
