package facade;

import multiton.MediaSystemRegistry;
import util.MediaType;

import java.io.File;

public class MultimediaSystemFacade {

    private MultimediaSystemFacade() {
    }

    /**Open animation file
     * @param mediaFilePath full path of the file */
    public static void openAnimation(String mediaFilePath) {
        MediaSystemRegistry.getInstance(MediaType.ANIMATION).open(new File(mediaFilePath));
        MediaSystemRegistry.getInstance(MediaType.ANIMATION).describe(new File(mediaFilePath));
    }

    /**Open audio file
     * @param mediaFilePath full path of the file */
    public static void playAudio(String mediaFilePath) {
        MediaSystemRegistry.getInstance(MediaType.AUDIO).open(new File(mediaFilePath));
        MediaSystemRegistry.getInstance(MediaType.AUDIO).describe(new File(mediaFilePath));
    }

    /**Open video file
     * @param mediaFilePath full path of the file */
    public static void playVideo(String mediaFilePath) {
        MediaSystemRegistry.getInstance(MediaType.VIDEO).open(new File(mediaFilePath));
        MediaSystemRegistry.getInstance(MediaType.VIDEO).describe(new File(mediaFilePath));
    }

    /** Open image file
     * @param mediaFilePath full path of the file */
    public static void openImage(String mediaFilePath) {
        MediaSystemRegistry.getInstance(MediaType.IMAGE).open(new File(mediaFilePath));
        MediaSystemRegistry.getInstance(MediaType.IMAGE).describe(new File(mediaFilePath));
    }

    /**Open graphic file
     * @param mediaFilePath full path of the file */
    public static void openGraphic(String mediaFilePath) {
        MediaSystemRegistry.getInstance(MediaType.GRAPHIC).open(new File(mediaFilePath));
        MediaSystemRegistry.getInstance(MediaType.GRAPHIC).describe(new File(mediaFilePath));

    }

    /**Open text file
     * @param mediaFilePath full path of the file */
    public static void openText(String mediaFilePath) {
        MediaSystemRegistry.getInstance(MediaType.TEXT).open(new File(mediaFilePath));
        MediaSystemRegistry.getInstance(MediaType.TEXT).describe(new File(mediaFilePath));
    }
}
